<?php
// Konfigurasi database
return [
    'host' => 'localhost', // Ganti sesuai host database
    'username' => 'arenasportiva',  // Ganti dengan username database hosting
    'password' => 'AA11BB2209!!',      // Ganti dengan password database hosting
    'database' => 'booking'// Ganti dengan nama database di hosting
];
?>
