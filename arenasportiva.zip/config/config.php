<?php
define('DB_HOST', 'localhost');
define('DB_USER', 'arenasportiva');
define('DB_PASS', 'AA11BB2209!!');
define('DB_NAME', 'booking');
